ImGrab
======

Chrome Extension to grab images from FaceBook comments.

**Instructions:**

1.) View images in active tab <br>
2.) Click extension icon to pull images to popup <br>
3.) Download images from popup or choose Window View <br> 4.) Drag and drop to download in Window View. Click for lightbox.